#ifndef IOT_H
#define IOT_H

#ifdef __cplusplus
extern "C"{

#endif
int add (int a, int b);
#ifdef __cplusplus
}
#endif
#endif